import java.awt.*;
import java.awt.event.*;


/**
 * Processa a mensagem de fecho da janela.
 */
class CloseWindowAndExit extends WindowAdapter {
  public void windowClosing (WindowEvent e) {
    System.exit (0);
  }
}
