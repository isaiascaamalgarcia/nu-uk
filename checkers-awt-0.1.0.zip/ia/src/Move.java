
/**
 * Serve para guardar movimentos
 */
class Move {
  /**
   * Casa de partida
   */
  private int from;
  
  /**
   * Casa destino
   */
  private int to;

  /**
   * Inicializa uma jogada.
   */
  Move (int moveFrom, int moveTo) {
    from = moveFrom;
    to = moveTo;
  }
  
  /**
   * Devolve a casa de partida
   */ 
  public int getFrom () {
    return from;
  }
  
  /**
   * Devolve a casa destino
   */ 
  public int getTo () {
    return to;
  }

  /**
   * Devolve uma representacao string da jogada
   */
  public String toString () {
    return "(" + from + "," + to + ")";
  }
}

