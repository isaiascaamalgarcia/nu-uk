import java.awt.*;
import java.awt.event.*;

/**
 *  Classe para apresentar mensagens de erro 'a semelhanca da
 * rotina MessageBox do Windows.
 */
public class MessageBox extends Dialog implements ActionListener {
  /**
   * Label que contem a mensagem a apresentar.
   */
  private Label label;

  /**
   * Butao responsavel pelo fecho da janela.
   */
  private Button ok;

  /**
   * Cria a janela de dialogo.
   * @param parent Pai da janela de dialogo.
   * @param title  Titulo da janela de dialogo.
   * @param mensagem Mensagem a apresentar ao utilizador.
   */
  public MessageBox (Frame parent, String title, String message) {
    super (parent, title, true);

    setSize (200, 100);
    setResizable (false);
    

    label = new Label (message, Label.CENTER);
    add (label, BorderLayout.CENTER);
    

    ok = new Button ("Ok");
    ok.addActionListener (this);
    add (ok, BorderLayout.SOUTH);

    addWindowListener (new CloseWindow ());
  }

  /**
   * Processa as mensagens de clique no butao ok
   */
  public void actionPerformed (ActionEvent event) {
    setVisible (false);
  }
}

