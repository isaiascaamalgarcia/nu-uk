import java.awt.*;
import java.awt.event.*;


/**
 * Processa a mensagem de fecho da janela.
 */
class CloseWindow extends WindowAdapter {
  public void windowClosing (WindowEvent e) {
    e.getWindow ().dispose ();
  }
}
