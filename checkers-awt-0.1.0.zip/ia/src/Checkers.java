import java.awt.*;
import java.awt.event.*;

/**
 * Janela principal da aplicacao
 */
public class Checkers extends Frame implements ActionListener {
  /**
   * Barra do menu
   */
  private MenuBar bar;

  /**
   * Menu de Opcoes
   */
  private Menu optionsMenu;

  /**
   * Opcao de recomeco
   */
  private MenuItem restartOption;

  /**
   * Opcao de gravar o jogo
   */
  private MenuItem saveOption;

  /**
   * Opcao de carregar o jogo
   */
  private MenuItem loadOption;  
  
  /**
   * Opcao de saida
   */
  private MenuItem exitOption;

  /**
   * Tabuleiro associado 'a aplicacao
   */
  private BoardView view;

  
  /**
   * Constructor
   */
  public Checkers () {
    super ("Checkers");

    view = new BoardView (this, new CheckersBoard ());
    add (view, BorderLayout.CENTER);
    
    addWindowListener (new CloseWindowAndExit ());

    optionsMenu = new Menu ("Opcoes");
    restartOption = new MenuItem ("Novo Jogo");
    restartOption.addActionListener (this);
    optionsMenu.add (restartOption);

    saveOption = new MenuItem ("Gravar ...");
    saveOption.addActionListener (this);
    optionsMenu.add (saveOption);

    loadOption = new MenuItem ("Abrir ...");
    loadOption.addActionListener (this);
    optionsMenu.add (loadOption);    

    optionsMenu.addSeparator ();
    exitOption = new MenuItem ("Sair");
    exitOption.addActionListener (this);
    optionsMenu.add (exitOption);

    bar = new MenuBar ();
    bar.add (optionsMenu);
    setMenuBar (bar);
  }

  /**
   * Permite correr como uma aplicacao <B> Java <B>
   */
  public static void  main (String args []) {
    Checkers c = new Checkers ();

    c.setSize (300, 300);
    c.setVisible (true);    
  }

  /**
   * Processa as mensagens do menu
   */
  public void actionPerformed (ActionEvent event) {
    FileDialog dlg;
    
    if (event.getSource () == exitOption)
      System.exit (0);
    else if (event.getSource () == restartOption)
      view.newGame ();
    else if (event.getSource () == saveOption) {
      dlg = new FileDialog (this, "Gravar", FileDialog.SAVE);
      dlg.setVisible (true);
      
      String fileName = dlg.getFile ();
      if (fileName != null)
        view.saveBoard (fileName);
    }
    else if (event.getSource () == loadOption) {
      dlg = new FileDialog (this, "Carregar", FileDialog.LOAD);
      dlg.setVisible (true);
      
      String fileName = dlg.getFile ();
      if (fileName != null)
        view.loadBoard (fileName);
    }

  }
}


