import java.lang.*;

/**
 * Representa a tentativa de efectuar uma jogada invalida
 */
public class BadCoord extends Exception {
}
