import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;


    
/**
 * Janela que representa o tabuleiro e processa os eventos do utilizador.
 */
public class BoardView extends Canvas {
  /**
   * Tabuleiro que contem os dados apresentados por BoardView
   */
  private CheckersBoard board;

  /**
   * Posicao do canto superior esquerdo.
   */
   int startX;
   int startY;

  /**
   * Largura das casas
   */
  int cellWidth;


  /**
   * Casas selecionadas, o primeiro elemento e' a peca selecionada
   */
  List selected;


  /**
   * Computador
   */
  Computer computer;
  
  /**
   * Dimensao da peca
   */
  private static final int SIZE = 0;
  

  /**
   * Janela onde o tabuleiro se encontra
   */
  private Frame parent;

  /**
   * Eventos do rato
   */
  private MouseHandler handler;
  


  /**
   * Constructor
   */
  public BoardView (Frame parentComponent, CheckersBoard b) {
    selected = new List ();
    board = b;
    parent = parentComponent;
    computer = new Computer (b);
    handler = new MouseHandler (this, parent);
    addMouseListener (handler);
  }

  /**
   * Devolve o tabuleiro associado
   */
  public CheckersBoard getBoard () {
    return board;
  }

  /**
   * Recomeca um novo jogo
   */
  public void newGame () {
    board.clearBoard ();
    selected.clear ();
    repaint ();
    handler.reset ();
    computer.play ();
    ChangeTitle ();
  }


  /**
   * Muda o titulo para reflectir o jogador corrente
   */
   public void ChangeTitle () {
    if (board.getCurrentPlayer () == CheckersBoard.WHITE)
      parent.setTitle ("Checkers - Brancas");
    else
      parent.setTitle ("Checkers - Pretas");
  }

  /**
   * Grava um tabuleiro
   */
  public void saveBoard (String fileName) {
    try {
      FileOutputStream ostream = new FileOutputStream (fileName);
      ObjectOutputStream p = new ObjectOutputStream(ostream);
      p.writeObject(board);
      p.flush();
      ostream.close();
    }
    catch (IOException e) {
      e.printStackTrace ();
      System.exit (1);
    }
  }

  /**
   * Carrega um tabuleiro
   */
  public void loadBoard (String fileName) {
    try {
      FileInputStream istream = new FileInputStream(fileName);
      ObjectInputStream p = new ObjectInputStream(istream);
      board = (CheckersBoard) p.readObject();
      istream.close();
      repaint ();
      
      computer.setBoard (board);
      ChangeTitle ();
    }
    catch (Exception e) {
      e.printStackTrace ();
      System.exit (1);
    }    
  }
  
  
    
    
  /**
   * Mostra o estado actual do tabuleiro.
   */
  public void paint (Graphics g) {
    Dimension d = getSize ();
    int marginX;
    int marginY;
    int incValue;

    Image image = createImage (d.width, d.height);
    Graphics gBuff = image.getGraphics ();

    // Limpa o buffer
    gBuff.setColor (Color.lightGray);
    gBuff.fillRect (0, 0, d.width, d.height);
    gBuff.setColor (Color.black);
    

    //  Calcula os incrementos de forma a obter um tabuleiro
    // quadrado
    if (d.width < d.height) {
      marginX = 0;
      marginY = (d.height - d.width) / 2;
      
      incValue = d.width / 8;
    }
    else  {
      marginX = (d.width - d.height) / 2;
      marginY = 0;
      
      incValue = d.height / 8;
    }

    startX = marginX;
    startY = marginY;
    cellWidth = incValue;
    
    drawBoard (gBuff, marginX, marginY, incValue);
    drawPieces (gBuff, marginX, marginY, incValue);

    g.drawImage (image, 0, 0, this);
  }

  /**
   * Desenha a parte do tabuleiro
   *
   * @param g Contexto onde desenha as pecas
   * @param marginX Margem horizontal do tabuleiro
   * @param marginY Margem vertical do tabuleiro
   * @param incValue Factor de incremento entre as casas do tabuleiro
   */
  private void drawBoard (Graphics g, int marginX, int marginY, int incValue) {
    int pos;
    
    for (int y = 0; y < 8; y++)
      for (int x = 0; x < 8; x++) {
        if ((x + y) % 2 == 0)
          g.setColor (Color.white);
        else {
          pos = y * 4 + (x + ((y % 2 == 0) ? - 1 : 0)) / 2;
          
          if (selected.has (new Integer (pos)))
            g.setColor (Color.green);
          else
            g.setColor (Color.black);
        }
        

        g.fillRect (marginX + x * incValue, marginY + y * incValue, incValue - 1, incValue - 1);    
      }
  }


  /**
   * Margem para as pecas que sao damas
   */
  private static final int KING_SIZE = 3;
  
  /**
   * Desenha as pecas existentes no tabuleiro
   *
   * @param g Contexto onde desenha as pecas
   * @param marginX Margem horizontal do tabuleiro
   * @param marginY Margem vertical do tabuleiro
   * @param incValue Factor de incremento entre as casas do tabuleiro onde as pecas sao
   *                desenhadas                
   */
  private void drawPieces (Graphics g, int marginX, int marginY, int incValue) {
    int x, y;
    for (int i = 0; i < 32; i++)
      try {
        if (board.getPiece (i) != CheckersBoard.EMPTY) {
          if (board.getPiece (i) == CheckersBoard.BLACK ||
              board.getPiece (i) == CheckersBoard.BLACK_KING)
            g.setColor (Color.red);
          else 
            g.setColor (Color.white);

          y = i / 4;
          x = (i % 4) * 2 + (y % 2 == 0 ? 1 : 0);
          g.fillOval (SIZE + marginX + x * incValue, SIZE + marginY + y * incValue,
                      incValue - 1 - 2 * SIZE, incValue - 1 - 2 * SIZE);

          if (board.getPiece (i) == CheckersBoard.WHITE_KING) {
            g.setColor (Color.black);
            g.drawOval (KING_SIZE + marginX + x * incValue, KING_SIZE + marginY + y * incValue,
                        incValue - 1 - 2 * KING_SIZE, incValue - 1 - 2 * KING_SIZE);
          }
          else if (board.getPiece (i) == CheckersBoard.BLACK_KING) {
            g.setColor (Color.white);
            g.drawOval (KING_SIZE + marginX + x * incValue, KING_SIZE + marginY + y * incValue,
                        incValue - 1 - 2 * KING_SIZE, incValue - 1 - 2 * KING_SIZE);
          }
          
            
          
        }
      }
      catch (BadCoord bad) {
        bad.printStackTrace ();
        System.exit (1);
      }
  }
 
}
    
  

/**
 * Classe para processar os eventos do rato para o tabuleiro
 */
class MouseHandler extends MouseAdapter {
  /**
   * Tabuleiro a que o evento esta associado
   */
  private BoardView view;

  /**
   * Pai do componente a que este evento esta' associado
   */
  private Frame parent;
  


  /**
   * tabuleiro temporario para jogadas multiplas
   */
  Stack boards;
  
  /**
   * @param boardView Tabuleiro que se encontra associado a estes eventos
   */
  public MouseHandler (BoardView boardView, Frame parentComponent) {
    view = boardView;
    parent = parentComponent;
    boards = new Stack ();
  }

  
  /**
   *  Processa a mensagem de pressao num botao
   *  Se for "clicado" numa casa com uma peca, se essa peca for do jogador,
   * ela fica selecionada.
   */
  public void mouseClicked (MouseEvent e) {
    int pos;
    MessageBox msg;
    


    pos = getPiecePos (e.getX (), e.getY ());
    if (pos != -1)
      try {
        CheckersBoard board = view.getBoard ();

        int piece = board.getPiece (pos);
        
        if (piece != CheckersBoard.EMPTY &&
            (((piece == CheckersBoard.WHITE || piece == CheckersBoard.WHITE_KING) &&
              board.getCurrentPlayer () == CheckersBoard.WHITE) ||
              ((piece == CheckersBoard.BLACK || piece == CheckersBoard.BLACK_KING) &&
              board.getCurrentPlayer () == CheckersBoard.BLACK))) {
          if (view.selected.isEmpty ())  // Se nao havia nenhuma selecionada
            view.selected.push_back (new Integer (pos));
          else {
            int temp = ((Integer) view.selected.peek_tail ()).intValue ();

            if (temp == pos) // Se estava selecionada, desceleciona
              view.selected.pop_back ();
            else {
              msg = new MessageBox (parent, "Erro", "Nao esta selecionada");
              msg.setVisible (true);
            }
          }
          
          
          view.repaint ();
          return;
        }
        else {
          boolean good = false;
          CheckersBoard tempBoard;
                    
          if (!view.selected.isEmpty ()) {
            // Obtem o tabuleiro corrente
            if (boards.empty ()) {
              tempBoard = (CheckersBoard) board.clone ();
              boards.push (tempBoard);
            }
            else
              tempBoard = (CheckersBoard) boards.peek ();
            

            int from = ((Integer) view.selected.peek_tail ()).intValue ();
            if (tempBoard.isValidMove (from, pos)) {
              tempBoard = (CheckersBoard) tempBoard.clone ();

              boolean isAttacking = tempBoard.mustAttack ();
              
              tempBoard.move (from, pos);
              
              if (isAttacking && tempBoard.mayAttack (pos)) {
                view.selected.push_back (new Integer (pos));
                boards.push (tempBoard);
                view.repaint ();
              }
              else {
                view.selected.push_back (new Integer (pos));
                makeMoves (view.selected, board);
                boards = new Stack ();
              }
              
              good = true;
            }
            else if (from == pos) {
              view.selected.pop_back ();
              boards.pop ();
              view.repaint ();
              good = true;
            }
          }
          
          if (!good) {
            msg = new MessageBox (parent, "Erro", "Jogada Invalida");
            msg.setVisible (true);
          }
        }
      }
      catch (BadCoord bad) {
        bad.printStackTrace ();
        System.exit (1);        
      }
      catch (BadMoveException bad) {
        bad.printStackTrace ();
        System.exit (1);        
      }
    }


  /**
   * Limpa as estruturas temporarias
   */
  public void reset () {
    boards = new Stack ();
  }
  


  /**
   * Efectua as jogadas do jogador humano, seguido do computador
   */
  private void makeMoves (List moves, CheckersBoard board) throws BadMoveException {
    List moveList = new List ();
    int from, to = 0;

    from = ((Integer) moves.pop_front ()).intValue ();
    while (!moves.isEmpty ()) {
      to = ((Integer) moves.pop_front ()).intValue ();
      moveList.push_back (new Move (from, to));
      from = to;
    }

    board.move (moveList);
    view.repaint (1);
    view.selected.clear ();
    reset ();
        

    if (!gameEnded ()) {
      view.ChangeTitle ();
      view.computer.play ();
      view.repaint ();

      if (!gameEnded ())
        view.ChangeTitle ();
    }
  }
    
  /**
   * Devolve o indice da peca seleciona
   * @returns Indice (0-31) da peca selecionada.
   *          No caso de nao estar nenhuma selecionada devolve -1.
   */
  private int getPiecePos (int currentX, int currentY) {
    for (int i = 0; i < 32; i++) {
      int x, y;

      y = i / 4;
      x = (i % 4) * 2 + (y % 2 == 0 ? 1 : 0);
      if (view.startX + x * view.cellWidth < currentX &&
          currentX < view.startX + (x + 1) * view.cellWidth &&
          view.startY + y * view.cellWidth < currentY &&
          currentY < view.startY + (y + 1) * view.cellWidth)
        return i;
    }

    return -1;
  }

  /**
   * Trata a situacao de fim de jogo
   */
  private boolean gameEnded () {
    MessageBox msg;
    CheckersBoard board = view.getBoard ();
    boolean result;

    int white = board.getWhitePieces ();
    int black = board.getBlackPieces ();
    if (board.hasEnded ()) {
      if (board.winner () == CheckersBoard.BLACK)
        msg = new MessageBox (parent, "Fim do Jogo", "Ganharam as pretas");
      else
        msg = new MessageBox (parent, "Fim do Jogo", "Ganharam as brancas");
      msg.setVisible (true);
      result = true;
    }
    else
      result = false;

    return result;
  }
  
}





